
public class LoginSecurity {
	private String username, password;
	
	//Set username and password
	void setUsername(String username) {
		this.username = username;
	}
	
	void setPassword(String password) {
		this.password = password;
	}
	
	//Get username and password
	String getUsername() {
		return username;
	}
	
	String getPassword() {
		return password;
	}

}
