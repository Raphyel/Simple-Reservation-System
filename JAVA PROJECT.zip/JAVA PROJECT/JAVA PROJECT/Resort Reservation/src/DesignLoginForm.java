import java.awt.BorderLayout;
import java.sql.*;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Component;

import javax.swing.ImageIcon;
import java.awt.Rectangle;
import javax.swing.border.LineBorder;
import javax.swing.event.AncestorListener;

import javax.swing.JPasswordField;
import java.awt.Font;
import java.awt.Image;

import javax.swing.SwingConstants;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JButton;


public class DesignLoginForm extends JFrame {
	
	Connection con;


	private Image img_logo = new ImageIcon(DesignLoginForm.class.getResource("res/bckG.png")).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
	private Image img_password = new ImageIcon(DesignLoginForm.class.getResource("res/KEY.png")).getImage().getScaledInstance(38, 38, Image.SCALE_SMOOTH);
	private Image img_log_in = new ImageIcon(DesignLoginForm.class.getResource("res/Log in.png")).getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
	private Image img_username = new ImageIcon(DesignLoginForm.class.getResource("res/Username.jpg")).getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
			
	private JPanel contentPane;
	private JTextField txtusername;
	private JLabel lblLoginMessage = new JLabel("");
	private JPasswordField txtpassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DesignLoginForm frame = new DesignLoginForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DesignLoginForm() {
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 576, 380);
		contentPane = new JPanel();
		contentPane.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		setContentPane(contentPane);
		setLocationRelativeTo(null);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(null);
		panel.setBounds(75, 151, 389, 43);
		panel.setBackground(Color.LIGHT_GRAY);
		contentPane.add(panel);
		panel.setLayout(null);
		
		txtusername = new JTextField();
		txtusername.setHorizontalAlignment(SwingConstants.LEFT);
		txtusername.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(txtusername.getText().equals("")) {
					txtusername.setText("");
				}
				else {
					txtusername.selectAll();
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(txtusername.getText().equals(""))
					txtusername.setText("");
					
					
			}
		});
		txtusername.setBorder(null);
		txtusername.setBounds(75, 11, 250, 21);
		panel.add(txtusername);
		txtusername.setColumns(25);
		
		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setFont(new Font("Book Antiqua", Font.BOLD, 12));
		lblNewLabel_1.setBounds(10, 11, 72, 21);
		panel.add(lblNewLabel_1);
		
		JLabel lblIconUsername = new JLabel("");
		lblIconUsername.setBounds(335, 0, 54, 43);
		panel.add(lblIconUsername);
		lblIconUsername.setHorizontalAlignment(SwingConstants.CENTER);
		lblIconUsername.setIcon(new ImageIcon(DesignLoginForm.class.getResource("/res/Username.jpg")));
		lblIconUsername.setIcon(new ImageIcon(img_username));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBorder(null);
		panel_1.setBounds(75, 205, 389, 43);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setFont(new Font("Book Antiqua", Font.BOLD, 12));
		lblNewLabel_2.setBounds(10, 14, 70, 14);
		panel_1.add(lblNewLabel_2);
		
		JLabel lblIconPassword = new JLabel("");
		lblIconPassword.setIcon(new ImageIcon(DesignLoginForm.class.getResource("/res/KEY.png")));
		lblIconPassword.setHorizontalAlignment(SwingConstants.CENTER);
		lblIconPassword.setBounds(335, 0, 54, 40);
		lblIconPassword.setIcon(new ImageIcon(img_password));
		panel_1.add(lblIconPassword);
		
		txtpassword = new JPasswordField();
		txtpassword.setBounds(75, 11, 250, 20);
		panel_1.add(txtpassword);
		
		JPanel btnlogin = new JPanel();
		btnlogin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				LoginSecurity log = new LoginSecurity();
				String username, password;
				
				//Set username and password for security
				log.setUsername(txtusername.getText());
				log.setPassword(txtpassword.getText());
				
				//Get username and password
				username = log.getUsername();
				password = log.getPassword();
				
				
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/booking_system", "root","");
					String query = "SELECT * FROM admin WHERE username='"+ username +"' AND password='"+ password +"'";
					Statement stm = con.createStatement();
					ResultSet rs = stm.executeQuery(query);
					
					if(rs.next()) {
						
						dispose();
						FrameDashBoard db = new FrameDashBoard();
						db.LoadTable();
						db.show();
						
					}
					else if(username.equals("") || password.equals("")) {
						JOptionPane.showMessageDialog(contentPane, "Empty username or password");
						
					}
					else {
						JOptionPane.showMessageDialog(contentPane, "Incorrect username or password");
						txtusername.setText("");
						txtpassword.setText("");
					}
					con.close();
				}
				catch(ClassNotFoundException e1) {
					e1.printStackTrace();
				}
				catch(SQLException e2) {
					e2.printStackTrace();
				}
				
				catch(Exception ex)
				{
					ex.printStackTrace();
				}
			}
		});
		btnlogin.setBounds(436, 305, 93, 33);
		contentPane.add(btnlogin);
		btnlogin.setLayout(null);
		
		JLabel lblLogin = new JLabel("LOG IN");
		lblLogin.setBounds(new Rectangle(20, 11, 54, 17));
		lblLogin.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogin.setFont(new Font("Book Antiqua", Font.BOLD, 14));
		btnlogin.add(lblLogin);
		
		JLabel lblX = new JLabel("X");
		lblX.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(JOptionPane.showConfirmDialog(contentPane, "Are you sure you want to close this application?", "Confirmation", JOptionPane.YES_NO_OPTION) ==0) {
					DesignLoginForm.this.dispose();
				}
			}
		});
		lblX.setFont(new Font("Book Antiqua", Font.BOLD, 15));
		lblX.setHorizontalAlignment(SwingConstants.CENTER);
		lblX.setBounds(529, 11, 34, 14);
		contentPane.add(lblX);
		
		lblLoginMessage.setForeground(Color.RED);
		lblLoginMessage.setHorizontalAlignment(SwingConstants.CENTER);
		lblLoginMessage.setFont(new Font("Book Antiqua", Font.BOLD, 12));
		lblLoginMessage.setBounds(75, 247, 389, 20);
		contentPane.add(lblLoginMessage);
		
		JLabel lblIconLogin = new JLabel("");
		lblIconLogin.setIcon(new ImageIcon(DesignLoginForm.class.getResource("/res/Log in.png")));
		lblIconLogin.setHorizontalAlignment(SwingConstants.CENTER);
		lblIconLogin.setBounds(208, 259, 133, 98);
		contentPane.add(lblIconLogin);
		
		JPanel btnexit = new JPanel();
		btnexit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(JOptionPane.showConfirmDialog(contentPane, "Are you sure you want to EXIT?", "Confirmation", JOptionPane.YES_NO_OPTION) ==0) {
					DesignLoginForm.this.dispose();
			}
		}
		});
		btnexit.setBackground(Color.WHITE);
		btnexit.setBounds(42, 305, 93, 33);
		contentPane.add(btnexit);
		btnexit.setLayout(null);
		
		JLabel lblExit = new JLabel("EXIT");
		lblExit.setFont(new Font("Book Antiqua", Font.BOLD, 14));
		lblExit.setHorizontalAlignment(SwingConstants.CENTER);
		lblExit.setBounds(0, 11, 97, 14);
		btnexit.add(lblExit);
		
		JLabel lblIconBckG = new JLabel("");
		lblIconBckG.setHorizontalTextPosition(SwingConstants.CENTER);
		lblIconBckG.setHorizontalAlignment(SwingConstants.CENTER);
		lblIconBckG.setIcon(new ImageIcon(DesignLoginForm.class.getResource("/res/bckG.png")));
		lblIconBckG.setBounds(3, 3, 570, 374);
		contentPane.add(lblIconBckG);
	}
}
