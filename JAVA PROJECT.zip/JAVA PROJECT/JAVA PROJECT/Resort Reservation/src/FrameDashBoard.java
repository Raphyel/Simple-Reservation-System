import java.awt.BorderLayout;
import java.sql.*;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import com.toedter.calendar.JDateChooser;

import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.DefaultComboBoxModel;

public class FrameDashBoard extends JFrame {
	private Image img_logo = new ImageIcon(DesignLoginForm.class.getResource("res/G3Logo.png")).getImage().getScaledInstance(300, 225, Image.SCALE_SMOOTH);
	private Image img_newbooking = new ImageIcon(DesignLoginForm.class.getResource("res/Newbooking.png")).getImage().getScaledInstance(135, 50, Image.SCALE_SMOOTH);
	private Image img_edit = new ImageIcon(DesignLoginForm.class.getResource("res/Edit.png")).getImage().getScaledInstance(135, 50, Image.SCALE_SMOOTH);
	private Image img_delete = new ImageIcon(DesignLoginForm.class.getResource("res/Delete.png")).getImage().getScaledInstance(135, 50, Image.SCALE_SMOOTH);
	private Image img_exit = new ImageIcon(DesignLoginForm.class.getResource("res/Exit.png")).getImage().getScaledInstance(135, 50, Image.SCALE_SMOOTH);
	private Image img_clear = new ImageIcon(DesignLoginForm.class.getResource("res/Clear.png")).getImage().getScaledInstance(135, 50, Image.SCALE_SMOOTH);
	
	
	private JPanel contentPane;
	private JTextField txtfname;
	private JTextField txtlname;
	private JTextField txtcontact;
	private JTextField txtemail;
	private JTable table;
	Connection con;
	PreparedStatement ps;
	DefaultTableModel model;
	CustomerSecurity cs = new CustomerSecurity();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrameDashBoard frame = new FrameDashBoard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void LoadTable() {
		try {
			connect();
			String loadTable = "SELECT * FROM customers";
			Statement stm = con.createStatement();
			ResultSet rs = stm.executeQuery(loadTable);
			
			while(rs.next()) {
				String firstName,
					   lastName,
					   conTact,
					   eMail,
					   aDdress,
					   numPerson,
					   daTe;
				
				cs.setFirstName(rs.getString("first_name"));
				cs.setLastName(rs.getString("last_name"));
				cs.setContactNo(rs.getString("contact"));
				cs.setEmailAdd(rs.getString("email"));
				cs.setAddress(rs.getString("address"));
				cs.setNumperson(rs.getString("no_of_customer"));
				cs.setDates(rs.getString("date"));
				
				firstName = cs.getFirstName();
				lastName = cs.getLastName();
				eMail = cs.getEmailAdd();
				aDdress = cs.getAddress();
				conTact = cs.getContactNo();
				numPerson = cs.getNumperson();
				daTe = cs.getDates();
				
				String tableData[] = {firstName, lastName, conTact, eMail, aDdress, numPerson, daTe};
				DefaultTableModel tblmodel = (DefaultTableModel)table.getModel();
				
				tblmodel.addRow(tableData);
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void connect() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/booking_system", "root","");
		}
		catch(ClassNotFoundException ex) {
			ex.printStackTrace();
		}
		catch(SQLException e1) {
			e1.printStackTrace();
		}
		
		catch(Exception e2)
		{
			e2.printStackTrace();
		}

	}

	/**
	 * Create the frame.
	 */
	public FrameDashBoard() {
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1200, 650);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JPanel panelMenu = new JPanel();
		panelMenu.setFont(new Font("Book Antiqua", Font.PLAIN, 25));
		panelMenu.setBackground(new Color(153, 180, 209));
		panelMenu.setBounds(0, 0, 277, 650);
		contentPane.add(panelMenu);
		panelMenu.setLayout(null);
		
		JLabel lblIconG3Logo = new JLabel("");
		lblIconG3Logo.setIcon(new ImageIcon(FrameDashBoard.class.getResource("/res/G3Logo.png")));
		lblIconG3Logo.setHorizontalAlignment(SwingConstants.CENTER);
		lblIconG3Logo.setBounds(59, 11, 164, 178);
		lblIconG3Logo.setIcon(new ImageIcon(img_logo));
		panelMenu.add(lblIconG3Logo);
		
		JLabel lblIconExit = new JLabel("");
		lblIconExit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
				DesignLoginForm log = new DesignLoginForm();
				log.show();
			}
		});
		lblIconExit.setBounds(59, 542, 127, 49);
		panelMenu.add(lblIconExit);
		lblIconExit.setIcon(new ImageIcon(FrameDashBoard.class.getResource("/res/Exit.png")));
		lblIconExit.setHorizontalAlignment(SwingConstants.CENTER);
		lblIconExit.setIcon(new ImageIcon(img_exit));
		
		JLabel lblNewLabel_1 = new JLabel("Resort");
		lblNewLabel_1.setFont(new Font("Book Antiqua", Font.PLAIN, 30));
		lblNewLabel_1.setBounds(86, 181, 100, 56);
		panelMenu.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("System");
		lblNewLabel_2.setFont(new Font("Book Antiqua", Font.PLAIN, 30));
		lblNewLabel_2.setBounds(86, 287, 96, 38);
		panelMenu.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Reservation");
		lblNewLabel_3.setFont(new Font("Book Antiqua", Font.PLAIN, 30));
		lblNewLabel_3.setBounds(52, 238, 183, 38);
		panelMenu.add(lblNewLabel_3);
		
		JPanel paneFirstname = new JPanel();
		paneFirstname.setBounds(407, 64, 302, 25);
		contentPane.add(paneFirstname);
		paneFirstname.setLayout(null);
		
		txtfname = new JTextField();
		txtfname.setBorder(null);
		txtfname.setBounds(10, 0, 282, 25);
		paneFirstname.add(txtfname);
		txtfname.setColumns(10);
		
		JPanel paneLastname = new JPanel();
		paneLastname.setBounds(407, 100, 302, 25);
		contentPane.add(paneLastname);
		paneLastname.setLayout(null);
		
		txtlname = new JTextField();
		txtlname.setBorder(null);
		txtlname.setBounds(10, 0, 282, 25);
		paneLastname.add(txtlname);
		txtlname.setColumns(10);
		
		JPanel paneContact = new JPanel();
		paneContact.setBounds(407, 136, 302, 25);
		contentPane.add(paneContact);
		paneContact.setLayout(null);
		
		txtcontact = new JTextField();
		txtcontact.setBorder(null);
		txtcontact.setBounds(10, 0, 282, 25);
		paneContact.add(txtcontact);
		txtcontact.setColumns(10);
		
		JPanel paneAddress = new JPanel();
		paneAddress.setBounds(407, 172, 302, 121);
		contentPane.add(paneAddress);
		paneAddress.setLayout(null);
		
		JTextPane txtaddress = new JTextPane();
		txtaddress.setBounds(10, 11, 282, 99);
		paneAddress.add(txtaddress);
		
		JPanel paneEmail = new JPanel();
		paneEmail.setBounds(945, 64, 245, 25);
		contentPane.add(paneEmail);
		paneEmail.setLayout(null);
		
		txtemail = new JTextField();
		txtemail.setBorder(null);
		txtemail.setBounds(10, 0, 225, 25);
		paneEmail.add(txtemail);
		txtemail.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("First name:");
		lblNewLabel.setFont(new Font("Book Antiqua", Font.BOLD, 15));
		lblNewLabel.setBounds(308, 64, 89, 25);
		contentPane.add(lblNewLabel);
		
		JLabel lblLastName = new JLabel("Last name:");
		lblLastName.setFont(new Font("Book Antiqua", Font.BOLD, 15));
		lblLastName.setBounds(308, 100, 89, 25);
		contentPane.add(lblLastName);
		
		JLabel lblContactNo = new JLabel("Contact No.:");
		lblContactNo.setFont(new Font("Book Antiqua", Font.BOLD, 15));
		lblContactNo.setBounds(308, 136, 89, 25);
		contentPane.add(lblContactNo);
		
		JLabel lblAddress = new JLabel("Address:");
		lblAddress.setFont(new Font("Book Antiqua", Font.BOLD, 15));
		lblAddress.setBounds(308, 172, 89, 25);
		contentPane.add(lblAddress);
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setHorizontalAlignment(SwingConstants.LEFT);
		lblEmail.setFont(new Font("Book Antiqua", Font.BOLD, 15));
		lblEmail.setBounds(825, 64, 118, 25);
		contentPane.add(lblEmail);
		
		JLabel lblNoOfPersons = new JLabel("No. of persons:");
		lblNoOfPersons.setFont(new Font("Book Antiqua", Font.BOLD, 15));
		lblNoOfPersons.setHorizontalAlignment(SwingConstants.LEFT);
		lblNoOfPersons.setBounds(825, 100, 118, 25);
		contentPane.add(lblNoOfPersons);
		
		JLabel lblDate = new JLabel("Date:");
		lblDate.setFont(new Font("Book Antiqua", Font.BOLD, 15));
		lblDate.setHorizontalAlignment(SwingConstants.LEFT);
		lblDate.setBounds(825, 136, 118, 25);
		contentPane.add(lblDate);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(945, 136, 119, 20);
		contentPane.add(dateChooser);
		
		JComboBox<?> cbperson = new JComboBox<Object>();
		cbperson.setModel(new DefaultComboBoxModel(new String[] {"5", "10", "15", "20", "25", "30", "35", "40", "45", "50"}));
		cbperson.setBounds(945, 100, 61, 22);
		contentPane.add(cbperson);
		
		model = new DefaultTableModel();
		Object[] col = {"First Name", "Last Name", "Contact", "Email", "Address", "Number of person", "Date"};
		Object[] row = new Object[7];
		
		model.setColumnIdentifiers(col);
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(287, 304, 903, 335);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setFillsViewportHeight(true);
		table.setColumnSelectionAllowed(true);
		table.setRowSelectionAllowed(true);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				try {
					DefaultTableModel model = (DefaultTableModel)table.getModel();
					int i = table.getSelectedRow();
					txtfname.setText(model.getValueAt(i, 0).toString());
					txtlname.setText(model.getValueAt(i, 1).toString());
					txtcontact.setText(model.getValueAt(i, 2).toString());
					txtemail.setText(model.getValueAt(i, 3).toString());
					txtaddress.setText(model.getValueAt(i, 4).toString());
					cbperson.setSelectedItem((String)model.getValueAt(i, 5).toString());
					java.util.Date dates = new SimpleDateFormat("yyyy-MM-dd").parse((String)model.getValueAt(i, 6).toString());
					dateChooser.setDate(dates);
				}
				catch(ParseException ex) {
					ex.printStackTrace();
				}
				catch(ClassCastException e1) {
					e1.printStackTrace();
				}
			}
		});
		scrollPane.setViewportView(table);
		table.setModel(model);
		
		JLabel lblIconNewbooking = new JLabel("");
		lblIconNewbooking.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String fname, lname, email, address, contact, person, date;
				DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
				
				cs.setFirstName(txtfname.getText());
				cs.setLastName(txtlname.getText());
				cs.setEmailAdd(txtemail.getText());
				cs.setContactNo(txtcontact.getText());
				cs.setAddress(txtaddress.getText());
				cs.setNumperson(cbperson.getSelectedItem().toString());
				cs.setDates(df.format(dateChooser.getDate()));
				
				fname = cs.getFirstName();
				lname = cs.getLastName();
				email = cs.getEmailAdd();
				address = cs.getAddress();
				contact = cs.getContactNo();
				person = cs.getNumperson();
				date = cs.getDates();
	
				if(fname.equals("") || lname.equals("") || email.equals("") || address.equals("") || contact.equals("") || date.equals("")) {
				JOptionPane.showMessageDialog(contentPane, "Please fill the information");
				
				}
				else {
					try {
						connect();
						String isExist = "SELECT * FROM customers WHERE date='"+date+"'";
						Statement stm = con.createStatement();
						ResultSet rs = stm.executeQuery(isExist);
						
						if(rs.next()) {
							
							JOptionPane.showMessageDialog(contentPane, "Sorry its already reserved.");
	
						}
						else {
							String reserve = "INSERT INTO customers(first_name, last_name, address, contact, email, no_of_customer, date)"
											+ "VALUES ('"+fname+"' , '"+lname+"' , '"+address+"' , '"+contact+"' , '"+email+"' , '"+person+"' , '"+date+"')";
							
							int x = stm.executeUpdate(reserve);
							JOptionPane.showMessageDialog(contentPane, "Reserve.");
							
							row[0] = fname;
							row[1] = lname;
							row[2] = contact;
							row[3] = email;
							row[4] = address;
							row[5] = person;
							row[6] = date;
							
							model.addRow(row);
							
							txtfname.setText("");
							txtlname.setText("");
							txtemail.setText("");
							txtaddress.setText("");
							txtcontact.setText("");
							cbperson.setSelectedIndex(0);
							dateChooser.setCalendar(null);
							
						}
						
						con.close();
					}
					
				
					catch(SQLException e1) {
						e1.printStackTrace();
					}
					catch(ClassCastException ex) {
						ex.printStackTrace();
					}
					
					catch(Exception e2)
					{
						e2.printStackTrace();
					}
				}
				
			}
		});
		lblIconNewbooking.setBounds(1039, 172, 127, 54);
		contentPane.add(lblIconNewbooking);
		lblIconNewbooking.setIcon(new ImageIcon(FrameDashBoard.class.getResource("/res/Newbooking.png")));
		lblIconNewbooking.setHorizontalAlignment(SwingConstants.CENTER);
		lblIconNewbooking.setIcon(new ImageIcon(img_newbooking));
		
		JLabel lblIconEdit = new JLabel("");
		lblIconEdit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					int i = table.getSelectedRow();
					if(i>=0) {
						model.setValueAt(txtfname.getText(), i, 0);
						model.setValueAt(txtlname.getText(), i, 1);
						model.setValueAt(txtcontact.getText(), i, 2);
						model.setValueAt(txtemail.getText(), i, 3);
						model.setValueAt(txtaddress.getText(), i, 4);
						model.setValueAt(cbperson.getSelectedItem(), i, 5);
						model.setValueAt(dateChooser.getDate(), i, 6);
						
						String fname, lname, email, address, contact, person, date;
						SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
						
						cs.setFirstName(txtfname.getText());
						cs.setLastName(txtlname.getText());
						cs.setEmailAdd(txtemail.getText());
						cs.setContactNo(txtcontact.getText());
						cs.setAddress(txtaddress.getText());
						cs.setNumperson(cbperson.getSelectedItem().toString());
						cs.setDates(df.format(dateChooser.getDate()));
						
						fname = cs.getFirstName();
						lname = cs.getLastName();
						email = cs.getEmailAdd();
						address = cs.getAddress();
						contact = cs.getContactNo();
						person = cs.getNumperson();
						date = cs.getDates();
						
						connect();
						String queryUpdate = "UPDATE customers SET first_name='"+fname+"', last_name='"+lname+"', "
											+ "address='"+address+"', contact='"+contact+"', email='"+email+"', "
											+ "no_of_customer='"+person+"', date='"+date+"' WHERE id='"+date+"'";
						ps = con.prepareStatement(queryUpdate);
						ps.executeUpdate();
						JOptionPane.showMessageDialog(contentPane, "Updated");
						
						txtfname.setText("");
						txtlname.setText("");
						txtemail.setText("");
						txtaddress.setText("");
						txtcontact.setText("");
						cbperson.setSelectedIndex(0);
						dateChooser.setCalendar(null);
					}
					else {
						JOptionPane.showMessageDialog(contentPane, "Please fill the information.");
					}
	
				}
				catch(SQLException e1) {
					e1.printStackTrace();
				}
				
				catch(Exception e2)
				{
					e2.printStackTrace();
				}
			}
		});
		lblIconEdit.setBounds(902, 177, 127, 49);
		contentPane.add(lblIconEdit);
		lblIconEdit.setIcon(new ImageIcon(FrameDashBoard.class.getResource("/res/Edit.png")));
		lblIconEdit.setHorizontalAlignment(SwingConstants.CENTER);
		lblIconEdit.setIcon(new ImageIcon(img_edit));
		
		JLabel lblIconDelete = new JLabel("");
		lblIconDelete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int i = table.getSelectedRow();
				
				try {
					if(i>=0) {
						model.setValueAt(txtfname.getText(), i, 0);
						model.setValueAt(txtlname.getText(), i, 1);
						model.setValueAt(txtcontact.getText(), i, 2);
						model.setValueAt(txtemail.getText(), i, 3);
						model.setValueAt(txtaddress.getText(), i, 4);
						model.setValueAt(cbperson.getSelectedItem(), i, 5);
						model.setValueAt(dateChooser.getDate(), i, 6);
						
						SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
						String date;
						cs.setDates(df.format(dateChooser.getDate()));
						date = cs.getDates();
						
						connect();	
						String queryDelete = "DELETE FROM customers WHERE date='"+date+"'";
						ps = con.prepareStatement(queryDelete);
						ps.execute();
						JOptionPane.showMessageDialog(contentPane, "Deleted");
						model.removeRow(i);
							
						txtfname.setText("");
						txtlname.setText("");
						txtemail.setText("");
						txtaddress.setText("");
						txtcontact.setText("");
						cbperson.setSelectedIndex(0);
						dateChooser.setCalendar(null);
					}else {
						JOptionPane.showMessageDialog(contentPane, "Please fill the information.");
					}

				}
				catch(SQLException e1) {
					e1.printStackTrace();
				}
				
				catch(Exception e2)
				{
					e2.printStackTrace();
				}
			}
		});
		lblIconDelete.setBounds(1039, 232, 127, 55);
		contentPane.add(lblIconDelete);
		lblIconDelete.setIcon(new ImageIcon(FrameDashBoard.class.getResource("/res/Delete.png")));
		lblIconDelete.setHorizontalAlignment(SwingConstants.CENTER);
		lblIconDelete.setIcon(new ImageIcon(img_delete));
		
		JLabel btnclear = new JLabel("");
		btnclear.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtfname.setText("");
				txtlname.setText("");
				txtemail.setText("");
				txtaddress.setText("");
				txtcontact.setText("");
				cbperson.setSelectedIndex(0);
				dateChooser.setCalendar(null);
			}
		});
		btnclear.setIcon(new ImageIcon(FrameDashBoard.class.getResource("/res/Clear.png")));
		btnclear.setBounds(894, 237, 135, 49);
		contentPane.add(btnclear);
		btnclear.setIcon(new ImageIcon(img_clear));
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.activeCaption);
		panel.setBounds(266, 0, 934, 30);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblX = new JLabel("X");
		lblX.setBounds(890, 11, 26, 14);
		panel.add(lblX);
		lblX.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(JOptionPane.showConfirmDialog(contentPane, "Are you sure you want to close this application?", "Confirmation", JOptionPane.YES_NO_OPTION) ==0) {
					FrameDashBoard.this.dispose();
					DesignLoginForm log = new DesignLoginForm();
					log.show();
				}
			}
		});
		lblX.setHorizontalAlignment(SwingConstants.CENTER);
		lblX.setFont(new Font("Book Antiqua", Font.BOLD, 15));
		
	}
}
